import Blog from "../models/Blog.js";
import Comment from "../models/Comment.js";

export async function addComment(req, res, next) {
  try {
    const text = req.body.text?.trim();
    if (!text) return res.status(400).json({ message: "Comment cannot be empty." });
    const blog = await Blog.findOne({ _id: req.params.blogId, published: true });
    if (!blog) return res.status(404).json({ message: "Blog not found." });
    const comment = await Comment.create({ blog: blog._id, author: req.user._id, text });
    await comment.populate("author", "name avatar");
    res.status(201).json({ comment });
  } catch (err) { next(err); }
}

export async function deleteComment(req, res, next) {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: "Comment not found." });
    const blog = await Blog.findById(comment.blog).select("author");
    if (String(comment.author) !== String(req.user._id) && String(blog?.author) !== String(req.user._id) && req.user.role !== "admin") {
      return res.status(403).json({ message: "You cannot delete this comment." });
    }
    await comment.deleteOne();
    res.json({ message: "Comment deleted." });
  } catch (err) { next(err); }
}
