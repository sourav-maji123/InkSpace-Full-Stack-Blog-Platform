import User from "../models/User.js";
import Blog from "../models/Blog.js";
import Comment from "../models/Comment.js";

export async function stats(req, res, next) {
  try {
    const [users, blogs, comments, recentBlogs] = await Promise.all([
      User.countDocuments(), Blog.countDocuments(), Comment.countDocuments(),
      Blog.find().populate("author", "name email").sort({ createdAt: -1 }).limit(5)
    ]);
    res.json({ stats: { users, blogs, comments }, recentBlogs });
  } catch (err) { next(err); }
}

export async function listUsers(req, res, next) {
  try {
    const users = await User.find().select("name email role createdAt").sort({ createdAt: -1 });
    res.json({ users });
  } catch (err) { next(err); }
}

export async function changeUserRole(req, res, next) {
  try {
    if (String(req.user._id) === req.params.id) return res.status(400).json({ message: "You cannot change your own role." });
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found." });
    user.role = user.role === "admin" ? "user" : "admin";
    await user.save();
    res.json({ user: { _id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (err) { next(err); }
}

export async function removeUser(req, res, next) {
  try {
    if (String(req.user._id) === req.params.id) return res.status(400).json({ message: "You cannot delete your own account here." });
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found." });
    const blogs = await Blog.find({ author: user._id }).select("_id");
    await Promise.all([
      user.deleteOne(),
      Blog.deleteMany({ author: user._id }),
      Comment.deleteMany({ $or: [{ author: user._id }, { blog: { $in: blogs.map(b => b._id) } }] })
    ]);
    res.json({ message: "User and their content deleted." });
  } catch (err) { next(err); }
}

export async function listAllBlogs(req, res, next) {
  try {
    const blogs = await Blog.find().populate("author", "name email").sort({ createdAt: -1 });
    res.json({ blogs });
  } catch (err) { next(err); }
}

export async function moderateBlog(req, res, next) {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: "Blog not found." });
    blog.published = !blog.published;
    await blog.save();
    res.json({ blog, message: blog.published ? "Blog published." : "Blog unpublished." });
  } catch (err) { next(err); }
}
