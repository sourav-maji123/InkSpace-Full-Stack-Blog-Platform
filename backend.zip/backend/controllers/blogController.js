import Blog from "../models/Blog.js";
import Comment from "../models/Comment.js";

const populateAuthor = { path: "author", select: "name avatar bio" };

export async function listBlogs(req, res, next) {
  try {
    const { search = "", category = "", page = "1", limit = "12" } = req.query;
    const filter = { published: true };
    if (category && category !== "All") filter.category = category;
    if (search.trim()) filter.$or = [
      { title: { $regex: search.trim(), $options: "i" } },
      { excerpt: { $regex: search.trim(), $options: "i" } },
      { content: { $regex: search.trim(), $options: "i" } },
      { tags: { $regex: search.trim(), $options: "i" } }
    ];
    const pageNum = Math.max(1, Number.parseInt(page, 10) || 1);
    const limitNum = Math.min(30, Math.max(1, Number.parseInt(limit, 10) || 12));
    const [blogs, total] = await Promise.all([
      Blog.find(filter).populate(populateAuthor).sort({ createdAt: -1 }).skip((pageNum - 1) * limitNum).limit(limitNum),
      Blog.countDocuments(filter)
    ]);
    res.json({ blogs, total, page: pageNum, pages: Math.ceil(total / limitNum) });
  } catch (err) { next(err); }
}

export async function getBlog(req, res, next) {
  try {
    const blog = await Blog.findById(req.params.id).populate(populateAuthor);
    if (!blog || (!blog.published && req.user?.role !== "admin" && String(blog.author?._id) !== String(req.user?._id))) return res.status(404).json({ message: "Blog not found." });
    const comments = await Comment.find({ blog: blog._id }).populate("author", "name avatar").sort({ createdAt: -1 });
    res.json({ blog, comments });
  } catch (err) { next(err); }
}

export async function createBlog(req, res, next) {
  try {
    const { title, excerpt, content, coverImage = "", category = "Writing", tags = [] } = req.body;
    if (!title?.trim() || !excerpt?.trim() || !content?.trim()) return res.status(400).json({ message: "Title, excerpt and content are required." });
    const blog = await Blog.create({
      title: title.trim(), excerpt: excerpt.trim(), content: content.trim(), coverImage,
      category, tags: Array.isArray(tags) ? tags : String(tags).split(",").map(t => t.trim()).filter(Boolean),
      author: req.user._id
    });
    await blog.populate(populateAuthor);
    res.status(201).json({ blog });
  } catch (err) { next(err); }
}

export async function updateBlog(req, res, next) {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: "Blog not found." });
    if (String(blog.author) !== String(req.user._id) && req.user.role !== "admin") return res.status(403).json({ message: "You can only edit your own posts." });
    const fields = ["title", "excerpt", "content", "coverImage", "category", "published"];
    fields.forEach(key => { if (req.body[key] !== undefined) blog[key] = req.body[key]; });
    if (req.body.tags !== undefined) blog.tags = Array.isArray(req.body.tags) ? req.body.tags : String(req.body.tags).split(",").map(t => t.trim()).filter(Boolean);
    await blog.save();
    await blog.populate(populateAuthor);
    res.json({ blog });
  } catch (err) { next(err); }
}

export async function deleteBlog(req, res, next) {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: "Blog not found." });
    if (String(blog.author) !== String(req.user._id) && req.user.role !== "admin") return res.status(403).json({ message: "You can only delete your own posts." });
    await Promise.all([blog.deleteOne(), Comment.deleteMany({ blog: blog._id })]);
    res.json({ message: "Blog deleted successfully." });
  } catch (err) { next(err); }
}

export async function toggleLike(req, res, next) {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog || !blog.published) return res.status(404).json({ message: "Blog not found." });
    const index = blog.likes.findIndex(id => String(id) === String(req.user._id));
    if (index >= 0) blog.likes.splice(index, 1); else blog.likes.push(req.user._id);
    await blog.save();
    res.json({ likes: blog.likes, liked: index < 0, count: blog.likes.length });
  } catch (err) { next(err); }
}

export async function myBlogs(req, res, next) {
  try {
    const blogs = await Blog.find({ author: req.user._id }).populate(populateAuthor).sort({ createdAt: -1 });
    res.json({ blogs });
  } catch (err) { next(err); }
}
