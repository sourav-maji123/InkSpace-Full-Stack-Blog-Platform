import User from "../models/User.js";
import Blog from "../models/Blog.js";
import { safeUser } from "../utils/token.js";

export async function updateProfile(req, res, next) {
  try {
    const { name, bio, avatar } = req.body;
    if (name !== undefined && !name.trim()) return res.status(400).json({ message: "Name cannot be empty." });
    if (name !== undefined) req.user.name = name.trim();
    if (bio !== undefined) req.user.bio = bio.trim();
    if (avatar !== undefined) req.user.avatar = avatar.trim();
    await req.user.save();
    res.json({ user: safeUser(req.user) });
  } catch (err) { next(err); }
}

export async function publicProfile(req, res, next) {
  try {
    const user = await User.findById(req.params.id).select("name bio avatar createdAt");
    if (!user) return res.status(404).json({ message: "User not found." });
    const blogs = await Blog.find({ author: user._id, published: true }).sort({ createdAt: -1 }).populate("author", "name avatar");
    res.json({ user, blogs });
  } catch (err) { next(err); }
}
