import jwt from "jsonwebtoken";

export function createToken(user) {
  return jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "7d" });
}

export function safeUser(user) {
  return {
    _id: user._id,
    name: user.name,
    email: user.email,
    bio: user.bio,
    avatar: user.avatar,
    role: user.role,
    createdAt: user.createdAt
  };
}
