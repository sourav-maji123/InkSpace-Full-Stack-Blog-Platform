import mongoose from "mongoose";

const blogSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 160 },
  excerpt: { type: String, required: true, trim: true, maxlength: 320 },
  content: { type: String, required: true },
  coverImage: { type: String, default: "" },
  category: { type: String, default: "Writing", trim: true },
  tags: [{ type: String, trim: true }],
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  published: { type: Boolean, default: true }
}, { timestamps: true });

blogSchema.index({ title: "text", excerpt: "text", content: "text", tags: "text" });
export default mongoose.model("Blog", blogSchema);
