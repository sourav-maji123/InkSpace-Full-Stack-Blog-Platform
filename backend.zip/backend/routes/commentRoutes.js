import { Router } from "express";
import { addComment, deleteComment } from "../controllers/commentController.js";
import { protect } from "../middleware/authMiddleware.js";
const router = Router();
router.post("/:blogId", protect, addComment);
router.delete("/:id", protect, deleteComment);
export default router;
