import { Router } from "express";
import { updateProfile, publicProfile } from "../controllers/userController.js";
import { protect } from "../middleware/authMiddleware.js";
const router = Router();
router.put("/profile", protect, updateProfile);
router.get("/:id", publicProfile);
export default router;
